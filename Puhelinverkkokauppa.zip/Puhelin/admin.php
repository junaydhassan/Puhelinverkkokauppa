<?php
require_once 'config.php';
if (!isset($_SESSION['kirjautunut']) || $_SESSION['kirjautunut'] !== true || 
    !isset($_SESSION['rooli']) || $_SESSION['rooli'] !== 'admin') {
    header("Location: index.php");
    exit();
}

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tuote_nimi = trim($_POST['tuote_nimi']);
    $hinta = trim($_POST['hinta']);
    $specs = trim($_POST['specs']);
    $kategoria_id = $_POST['kategoria'];
    
    if (empty($tuote_nimi) || empty($hinta) || empty($specs) || empty($kategoria_id)) {
        $message = 'Tuotteen nimi, hinta, specs ja kategoria ovat pakollisia!';
        $messageType = 'error';
    } elseif (!is_numeric($hinta) || $hinta <= 0) {
        $message = 'Hinta tulee olla positiivinen numero!';
        $messageType = 'error';
    } elseif (!in_array($kategoria_id, ['1', '2', '3'])) {
        $message = 'Virheellinen kategoria!';
        $messageType = 'error';
    } elseif (!isset($_FILES['kuva']) || $_FILES['kuva']['error'] === UPLOAD_ERR_NO_FILE) {
        $message = 'Kuva on pakollinen!';
        $messageType = 'error';
    } else {
        // Handle file upload
        $upload_dir = 'kuvat/';
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $max_file_size = 5 * 1024 * 1024; // 5MB
        
        $file = $_FILES['kuva'];
        $file_type = $file['type'];
        $file_size = $file['size'];
        $file_tmp = $file['tmp_name'];
        $file_error = $file['error'];
        
        if ($file_error !== UPLOAD_ERR_OK) {
            $message = 'Virhe kuvan latauksessa!';
            $messageType = 'error';
        } elseif (!in_array($file_type, $allowed_types)) {
            $message = 'Virheellinen kuvatiedosto! Sallitut tiedostotyypit: JPG, PNG, GIF, WEBP';
            $messageType = 'error';
        } elseif ($file_size > $max_file_size) {
            $message = 'Kuva on liian suuri! Maksimikoko: 5MB';
            $messageType = 'error';
        } else {
            // Generate unique filename
            $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $unique_filename = uniqid() . '_' . time() . '.' . $file_extension;
            $upload_path = $upload_dir . $unique_filename;
            
            // Create directory if it doesn't exist
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            if (move_uploaded_file($file_tmp, $upload_path)) {
                try {
                    $stmt = $pdo->prepare("SELECT id FROM puh_tuotteet WHERE nimi = ?");
                    $stmt->execute([$tuote_nimi]);
                    
                    if ($stmt->rowCount() > 0) {
                        // Delete uploaded file if product already exists
                        unlink($upload_path);
                        $message = 'Tuote on jo olemassa!';
                        $messageType = 'error';
                    } else {
                        $stmt = $pdo->prepare("INSERT INTO puh_tuotteet (kategoria_id, nimi, hinta, specs, kuvan_url) VALUES (?, ?, ?, ?, ?)");
                        
                        if ($stmt->execute([$kategoria_id, $tuote_nimi, $hinta, $specs, $unique_filename])) {
                            $message = 'Tuote lisätty onnistuneesti!';
                            $messageType = 'success';
                            $_POST = array();
                        } else {
                            unlink($upload_path);
                            $message = 'Virhe tuotteen lisäämisessä!';
                            $messageType = 'error';
                        }
                    }
                } catch(PDOException $e) {
                    unlink($upload_path);
                    $message = 'Tietokantavirhe: ' . $e->getMessage();
                    $messageType = 'error';
                }
            } else {
                $message = 'Virhe kuvan tallentamisessa!';
                $messageType = 'error';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PhoneShop - Admin Panel</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* ...existing code... */

        .admin-field input[type="file"] {
            padding: 8px 10px;
            font-size: 16px;
            border: 2px dashed #dcdcdc;
            border-radius: 4px;
            background: #fff;
            color: #000;
            cursor: pointer;
        }

        .admin-field input[type="file"]:hover {
            border-color: #6b1fa3;
        }

        .file-info {
            margin-top: 8px;
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
        }

        .image-preview {
            margin-top: 10px;
            max-width: 200px;
            border-radius: 8px;
            display: none;
        }
        body.admin-page {
            min-height: 100vh;
            margin: 0;
            display: flex;
            flex-direction: column;
            background: linear-gradient(135deg, #6b1fa3 0%, #f5f1ff 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .admin-header {
            background-color: #6b1fa3;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            height: 120px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);
        }

        .admin-back {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
        }

        .admin-back a {
            display: inline-block;
            background: #ffffff;
            color: #1f1f1f;
            text-decoration: none;
            font-weight: 600;
            font-size: 20px;
            padding: 14px 26px;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
        }

        .admin-logout {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
        }

        .admin-logout a {
            display: inline-block;
            background: #ffffff;
            color: #1f1f1f;
            text-decoration: none;
            font-weight: 600;
            font-size: 20px;
            padding: 14px 26px;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
        }

        .admin-title {
            font-size: 26px;
            font-weight: 700;
            font-style: italic;
            color: #ffffff;
            margin: 0;
        }

        .admin-wrapper {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px 60px;
        }

        .admin-card {
            background: #6b1fa3;
            border-radius: 30px;
            border: 3px solid #5a52c0;
            padding: 40px 50px 50px;
            max-width: 600px;
            width: 100%;
            color: #fff;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);
        }

        .admin-card h1 {
            text-align: center;
            margin: 0 0 30px;
            font-size: 26px;
            font-weight: 700;
        }

        .admin-field {
            display: flex;
            flex-direction: column;
            margin-bottom: 22px;
            font-size: 18px;
            font-weight: 600;
        }

        .admin-field label {
            margin-bottom: 8px;
        }

        .admin-field input,
        .admin-field select,
        .admin-field textarea {
            padding: 12px 10px;
            font-size: 16px;
            border: 1px solid #dcdcdc;
            border-radius: 4px;
            background: #fff;
            color: #000;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .admin-field textarea {
            resize: vertical;
            min-height: 100px;
        }

        .admin-actions {
            text-align: center;
            margin-top: 30px;
        }

        .admin-submit {
            background: #ffffff;
            color: #6b1fa3;
            font-weight: 700;
            border: none;
            border-radius: 8px;
            padding: 14px 32px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
        }

        .admin-submit:hover {
            filter: brightness(0.95);
        }

        .message {
            margin-bottom: 20px;
            padding: 12px 14px;
            border-radius: 6px;
            font-size: 15px;
            background: rgba(255, 255, 255, 0.15);
            text-align: center;
        }

        .message.success {
            background: rgba(34, 197, 94, 0.3);
            border: 1px solid rgba(34, 197, 94, 0.5);
        }

        .message.error {
            background: rgba(239, 68, 68, 0.3);
            border: 1px solid rgba(239, 68, 68, 0.5);
        }

        .admin-footer {
            background-color: #6b1fa3;
            padding: 50px 20px;
            text-align: center;
            margin-top: auto;
        }

        @media (max-width: 640px) {
            .admin-card {
                padding: 30px 24px 36px;
                border-radius: 22px;
            }

            .admin-back a,
            .admin-logout a {
                font-size: 16px;
                padding: 10px 18px;
            }
        }
        /* ...existing code... */
    </style>
</head>
<body class="admin-page">
    <header class="admin-header">
        <div class="admin-back"><a href="index.php">Etusivu</a></div>
        <h2 class="admin-title">PhoneShop Admin</h2>
        <div class="admin-logout"><a href="logout.php">Kirjaudu ulos</a></div>
    </header>

    <main class="admin-wrapper">
        <div class="admin-card">
            <form method="POST" action="" enctype="multipart/form-data">
                <h1>Tuotteen lisääminen</h1>
                
                <?php if (!empty($message)): ?>
                    <div class="message <?php echo $messageType; ?>">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
                
                <div class="admin-field">
                    <label for="tuote_nimi">Tuotteen nimi:</label>
                    <input type="text" name="tuote_nimi" id="tuote_nimi" required 
                           placeholder="esim. iPhone 15 Pro"
                           value="<?php echo isset($_POST['tuote_nimi']) ? htmlspecialchars($_POST['tuote_nimi']) : ''; ?>">
                </div>
                
                <div class="admin-field">
                    <label for="hinta">Hinta (€):</label>
                    <input type="number" name="hinta" id="hinta" 
                           min="0.01" 
                           step="0.01" 
                           required 
                           placeholder="esim. 999.99"
                           value="<?php echo isset($_POST['hinta']) ? htmlspecialchars($_POST['hinta']) : ''; ?>">
                </div>
                
                <div class="admin-field">
                    <label for="specs">Tekniset tiedot:</label>
                    <textarea name="specs" id="specs" required 
                              placeholder="Tuotteen tekniset tiedot..."><?php echo isset($_POST['specs']) ? htmlspecialchars($_POST['specs']) : ''; ?></textarea>
                </div>
                
                <div class="admin-field">
                    <label for="kuva">Tuotekuva:</label>
                    <input type="file" name="kuva" id="kuva" accept="image/*" required onchange="previewImage(event)">
                    <div class="file-info">Maksimikoko: 5MB. Sallitut tiedostotyypit: JPG, PNG, GIF, WEBP</div>
                    <img id="imagePreview" class="image-preview" alt="Kuvan esikatselu">
                </div>
                
                <div class="admin-field">
                    <label for="kategoria">Tuotekategoria:</label>
                    <select name="kategoria" id="kategoria" required>
                        <option value="" selected>Valitse kategoria</option>
                        <option value="1">Puhelin</option>
                        <option value="2">Kuori</option>
                        <option value="3">Laturi</option>
                    </select>
                </div>
                
                <div class="admin-actions">
                    <input class="admin-submit" type="submit" value="Lisää tuote">
                </div>
            </form>
        </div>
    </main>

    <footer class="admin-footer">
    </footer>

    <script>
        function previewImage(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('imagePreview');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html>