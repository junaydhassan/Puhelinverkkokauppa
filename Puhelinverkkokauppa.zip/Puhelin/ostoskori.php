<?php
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['kirjautunut']) || $_SESSION['kirjautunut'] !== true) {
    header("Location: login.php");
    exit();
}

$kayttaja_id = $_SESSION['kayttaja_id'];
$nimi = $_SESSION['nimi'] ?? 'Käyttäjä';

// Fetch cart items
$stmt = $pdo->prepare("SELECT o.tuote_id, o.maara, t.nimi, t.hinta, t.kuvan_url 
                       FROM puh_ostoskori o 
                       JOIN puh_tuotteet t ON o.tuote_id = t.id 
                       WHERE o.kayttaja_id = ?");
$stmt->execute([$kayttaja_id]);
$cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total
$total = 0;
foreach ($cartItems as $item) {
    $total += $item['hinta'] * $item['maara'];
}

// Handle order placement
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    if (empty($cartItems)) {
        $message = 'Ostoskori on tyhjä!';
        $messageType = 'error';
    } else {
        try {
            // Start transaction
            $pdo->beginTransaction();
            
            // Create order
            $stmt = $pdo->prepare("INSERT INTO puh_tilaus (asiakas_id, yhteensa) VALUES (?, ?)");
            $stmt->execute([$kayttaja_id, $total]);
            $tilaus_id = $pdo->lastInsertId();
            
            // Insert order items
            $stmt = $pdo->prepare("INSERT INTO puh_tilaukset_tuotteet (tilaus_id, tuote_id, maara) VALUES (?, ?, ?)");
            foreach ($cartItems as $item) {
                $stmt->execute([$tilaus_id, $item['tuote_id'], $item['maara']]);
            }
            
            // Clear cart
            $stmt = $pdo->prepare("DELETE FROM puh_ostoskori WHERE kayttaja_id = ?");
            $stmt->execute([$kayttaja_id]);
            
            // Commit transaction
            $pdo->commit();
            
            $message = 'Tilaus tehty onnistuneesti! Tilausnumero: ' . $tilaus_id;
            $messageType = 'success';
            
            // Clear cart items array
            $cartItems = [];
            $total = 0;
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $message = 'Virhe tilauksen tekemisessä: ' . $e->getMessage();
            $messageType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PhoneShop - Ostoskori</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Ostoskori-sivun tyylit */
        body.cart-page {
            min-height: 100vh;
            margin: 0;
            display: flex;
            flex-direction: column;
            background-color: #f5f5f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .cart-header {
            background-color: #7c3aed;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            height: 120px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);
        }

        .cart-back {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
        }

        .cart-back a {
            display: inline-block;
            background: #ffffff;
            color: #1f1f1f;
            text-decoration: none;
            font-weight: 600;
            font-size: 20px;
            padding: 14px 26px;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            transition: background-color 0.2s;
        }

        .cart-back a:hover {
            background-color: #e8e8e8;
        }

        .cart-header-right {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #fff;
            font-size: 16px;
            font-weight: 600;
        }

        .cart-title {
            font-size: 26px;
            font-weight: 700;
            font-style: italic;
            color: #ffffff;
            margin: 0;
        }

        .cart-main {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 40px 20px 60px;
            max-width: 1200px;
            width: 100%;
            margin: 0 auto;
        }

        .cart-heading {
            font-size: 32px;
            font-weight: 700;
            color: #333;
            margin-bottom: 30px;
        }

        .message-box {
            width: 100%;
            max-width: 800px;
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 16px;
            font-weight: 600;
            text-align: center;
        }

        .message-box.success {
            background-color: #22c55e;
            color: white;
        }

        .message-box.error {
            background-color: #ef4444;
            color: white;
        }

        .cart-content {
            width: 100%;
            max-width: 800px;
        }

        .cart-items-list {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .empty-cart-message {
            text-align: center;
            padding: 60px 20px;
            color: #666;
            font-size: 18px;
        }

        .checkout-item {
            display: flex;
            gap: 20px;
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            align-items: center;
        }

        .checkout-item:last-child {
            border-bottom: none;
        }

        .checkout-item-image {
            width: 80px;
            height: 80px;
            object-fit: contain;
            background: #f9f9f9;
            border-radius: 8px;
            padding: 10px;
        }

        .checkout-item-details {
            flex: 1;
        }

        .checkout-item-name {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }

        .checkout-item-price {
            font-size: 16px;
            color: #666;
            margin-bottom: 8px;
        }

        .checkout-item-quantity {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-top: 8px;
        }

        .quantity-btn {
            background: #7c3aed;
            color: white;
            border: none;
            width: 32px;
            height: 32px;
            border-radius: 6px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.2s;
        }

        .quantity-btn:hover {
            background: #6d28d9;
        }

        .quantity-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        .quantity-display {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            min-width: 40px;
            text-align: center;
        }

        .checkout-item-total {
            font-size: 18px;
            font-weight: 700;
            color: #7c3aed;
            text-align: right;
            min-width: 100px;
        }

        .remove-item-btn {
            background: #ef4444;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: background-color 0.2s;
        }

        .remove-item-btn:hover {
            background: #dc2626;
        }

        .cart-summary {
            background: #7c3aed;
            border-radius: 16px;
            padding: 30px;
            color: white;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            font-size: 16px;
        }

        .summary-total {
            display: flex;
            justify-content: space-between;
            padding-top: 15px;
            border-top: 2px solid rgba(255, 255, 255, 0.3);
            margin-top: 15px;
            font-size: 24px;
            font-weight: 700;
        }

        .order-button {
            background: #ffffff;
            color: #7c3aed;
            font-weight: 700;
            border: none;
            border-radius: 12px;
            padding: 16px 40px;
            font-size: 18px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
            transition: all 0.2s;
        }

        .order-button:hover {
            background-color: #f0f0f0;
            transform: translateY(-2px);
        }

        .order-button:disabled {
            background-color: #ccc;
            color: #666;
            cursor: not-allowed;
            transform: none;
        }

        .cart-footer {
            background-color: #EDEDED;
            padding: 40px 20px;
            text-align: center;
            margin-top: auto;
        }

        @media (max-width: 768px) {
            .cart-heading {
                font-size: 26px;
            }

            .checkout-item {
                flex-wrap: wrap;
            }

            .checkout-item-image {
                width: 60px;
                height: 60px;
            }

            .checkout-item-total {
                width: 100%;
                text-align: left;
                margin-top: 10px;
            }

            .cart-back a {
                font-size: 16px;
                padding: 10px 18px;
            }
        }
    </style>
</head>
<body class="cart-page">
    <header class="cart-header">
        <div class="cart-back"><a href="index.php">Takaisin</a></div>
        <h2 class="cart-title">PhoneShop</h2>
        <div class="cart-header-right">
            Tervetuloa, <?php echo htmlspecialchars($nimi); ?>!
        </div>
    </header>

    <main class="cart-main">
        <h1 class="cart-heading">Ostoskori</h1>

        <?php if (!empty($message)): ?>
            <div class="message-box <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="cart-content">
            <div class="cart-items-list">
                <?php if (empty($cartItems)): ?>
                    <div class="empty-cart-message">
                        <p>Ostoskorisi on tyhjä</p>
                        <p style="margin-top: 20px;">
                            <a href="index.php" style="color: #7c3aed; text-decoration: underline; font-weight: 600;">Jatka ostoksia</a>
                        </p>
                    </div>
                <?php else: ?>
                    <?php foreach ($cartItems as $item): ?>
                        <div class="checkout-item" id="item-<?php echo $item['tuote_id']; ?>">
                            <img src="kuvat/<?php echo htmlspecialchars($item['kuvan_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($item['nimi']); ?>" 
                                 class="checkout-item-image">
                            <div class="checkout-item-details">
                                <div class="checkout-item-name"><?php echo htmlspecialchars($item['nimi']); ?></div>
                                <div class="checkout-item-price">
                                    <?php echo number_format($item['hinta'], 2, ',', ' '); ?> € / kpl
                                </div>
                                <div class="checkout-item-quantity">
                                    <button class="quantity-btn" onclick="updateQuantity(<?php echo $item['tuote_id']; ?>, <?php echo $item['maara'] - 1; ?>)">-</button>
                                    <span class="quantity-display" id="quantity-<?php echo $item['tuote_id']; ?>"><?php echo $item['maara']; ?></span>
                                    <button class="quantity-btn" onclick="updateQuantity(<?php echo $item['tuote_id']; ?>, <?php echo $item['maara'] + 1; ?>)">+</button>
                                </div>
                            </div>
                            <div class="checkout-item-total" id="total-<?php echo $item['tuote_id']; ?>">
                                <?php echo number_format($item['hinta'] * $item['maara'], 2, ',', ' '); ?> €
                            </div>
                            <button class="remove-item-btn" onclick="removeItem(<?php echo $item['tuote_id']; ?>)">
                                Poista
                            </button>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <?php if (!empty($cartItems)): ?>
                <div class="cart-summary">
                    <div class="summary-row">
                        <span>Tuotteet yhteensä:</span>
                        <span id="summary-total"><?php echo number_format($total, 2, ',', ' '); ?> €</span>
                    </div>
                    <div class="summary-row">
                        <span>Toimitus:</span>
                        <span>0,00 €</span>
                    </div>
                    <div class="summary-total">
                        <span>Yhteensä:</span>
                        <span id="final-total"><?php echo number_format($total, 2, ',', ' '); ?> €</span>
                    </div>
                    <form method="POST" action="">
                        <button type="submit" name="place_order" class="order-button">
                            Tilaa nyt
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <footer class="cart-footer">
    </footer>

    <script>
        function updateQuantity(productId, newQuantity) {
            if (newQuantity < 1) {
                removeItem(productId);
                return;
            }

            fetch('cart_handler.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=update&tuote_id=${productId}&maara=${newQuantity}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Virhe määrän päivityksessä');
                }
            })
            .catch(error => {
                console.error('Virhe:', error);
                alert('Tapahtui virhe');
            });
        }

        function removeItem(productId) {
            if (confirm('Haluatko varmasti poistaa tuotteen ostoskorista?')) {
                fetch('cart_handler.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=update&tuote_id=${productId}&maara=0`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert('Virhe tuotteen poistamisessa');
                    }
                })
                .catch(error => {
                    console.error('Virhe:', error);
                    alert('Tapahtui virhe');
                });
            }
        }
    </script>
</body>
</html>