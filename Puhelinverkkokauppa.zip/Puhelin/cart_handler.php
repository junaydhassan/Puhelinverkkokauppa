<?php
require_once 'config.php';

header('Content-Type: application/json');

// Debug: Log all session data
error_log("Session data: " . print_r($_SESSION, true));
error_log("POST data: " . print_r($_POST, true));

// Check if user is logged in
if (!isset($_SESSION['kirjautunut']) || $_SESSION['kirjautunut'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Et ole kirjautunut', 'debug' => 'not_logged_in']);
    exit();
}

// Check if kayttaja_id exists in session
if (!isset($_SESSION['kayttaja_id'])) {
    echo json_encode(['success' => false, 'message' => 'Käyttäjä-ID puuttuu sessiosta', 'debug' => 'no_user_id', 'session' => $_SESSION]);
    exit();
}

$kayttaja_id = $_SESSION['kayttaja_id'];
$action = $_POST['action'] ?? '';

try {
    switch ($action) {
        case 'add':
            $tuote_id = intval($_POST['tuote_id']);
            
            // Check if product exists
            $stmt = $pdo->prepare("SELECT id FROM puh_tuotteet WHERE id = ?");
            $stmt->execute([$tuote_id]);
            if ($stmt->rowCount() === 0) {
                echo json_encode(['success' => false, 'message' => 'Tuotetta ei löytynyt', 'debug' => 'product_not_found']);
                exit();
            }
            
            // Add or update cart item
            $stmt = $pdo->prepare("INSERT INTO puh_ostoskori (kayttaja_id, tuote_id, maara) 
                                   VALUES (?, ?, 1) 
                                   ON DUPLICATE KEY UPDATE maara = maara + 1");
            $stmt->execute([$kayttaja_id, $tuote_id]);
            
            echo json_encode(['success' => true, 'message' => 'Tuote lisätty ostoskoriin', 'debug' => 'success']);
            break;
            
        case 'update':
            $tuote_id = intval($_POST['tuote_id']);
            $maara = intval($_POST['maara']);
            
            if ($maara <= 0) {
                $stmt = $pdo->prepare("DELETE FROM puh_ostoskori WHERE kayttaja_id = ? AND tuote_id = ?");
                $stmt->execute([$kayttaja_id, $tuote_id]);
            } else {
                $stmt = $pdo->prepare("UPDATE puh_ostoskori SET maara = ? WHERE kayttaja_id = ? AND tuote_id = ?");
                $stmt->execute([$maara, $kayttaja_id, $tuote_id]);
            }
            
            echo json_encode(['success' => true, 'message' => 'Ostoskori päivitetty']);
            break;
            
        case 'get':
            $stmt = $pdo->prepare("SELECT o.tuote_id, o.maara, t.nimi, t.hinta, t.kuvan_url 
                                   FROM puh_ostoskori o 
                                   JOIN puh_tuotteet t ON o.tuote_id = t.id 
                                   WHERE o.kayttaja_id = ?");
            $stmt->execute([$kayttaja_id]);
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $total = 0;
            foreach ($items as $item) {
                $total += $item['hinta'] * $item['maara'];
            }
            
            echo json_encode(['success' => true, 'items' => $items, 'total' => $total]);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Virheellinen toiminto', 'debug' => 'invalid_action', 'action' => $action]);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Tietokantavirhe: ' . $e->getMessage(), 'debug' => 'database_error']);
}
?>