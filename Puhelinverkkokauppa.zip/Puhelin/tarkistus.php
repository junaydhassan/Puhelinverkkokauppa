<?php
require_once 'config.php';

// CSRF validation
if (!isset($_POST['csrf_token'], $_SESSION['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die("CSRF-tunniste ei kelpaa!");
}

// Validation function
function tarkistaSyote($nimi, $sahkoposti) {
    // Clean inputs
    $nimi = htmlspecialchars(trim($nimi));
    $sahkoposti = htmlspecialchars(trim($sahkoposti));
    
    // Validate name length
    if (strlen($nimi) > 100) return "Nimi on liian pitkä!";
    
    // Validate email format
    if (!filter_var($sahkoposti, FILTER_VALIDATE_EMAIL)) return "Virheellinen sähköposti!";
    
    // Validate email length
    if (strlen($sahkoposti) > 255) return "Sähköposti on liian pitkä!";
    
    // Validate email domain
    $domain = explode('@', $sahkoposti)[1] ?? '';
    if (!checkdnsrr($domain, 'MX')) return "Sähköpostin domain ei ole toimiva!";
    
    return [
        'nimi' => $nimi,
        'sahkoposti' => $sahkoposti
    ];
}

// Get form data
$tulos = tarkistaSyote($_POST['nimi'], $_POST['gmail']);

// If validation error, display error
if (is_array($tulos)) {
    // Create log entry
    $rivi = date("Y-m-d H:i:s") . " | Nimi: {$tulos['nimi']} | Sähköposti: {$tulos['sahkoposti']}" . PHP_EOL;
    $tiedosto = 'tiedot.txt';
    
    // Append to file
    if (file_put_contents($tiedosto, $rivi, FILE_APPEND | LOCK_EX)) {
        echo "Tiedot tallennettu tiedostoon!";
    } else {
        echo "Tiedoston kirjoittaminen epäonnistui!";
    }
} else {
    // Display validation error
    echo "Virhe: " . $tulos;
}

?>