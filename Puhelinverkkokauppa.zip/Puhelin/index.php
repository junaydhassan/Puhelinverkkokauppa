<?php
require_once 'config.php';

$isLoggedIn = isset($_SESSION['kirjautunut']) && $_SESSION['kirjautunut'] === true;
$nimi = $_SESSION['nimi'] ?? 'Unknown User';

// Handle category selection
$category = isset($_GET['category']) ? intval($_GET['category']) : 1; // Default to category 1 (Phones)

// Handle search
$searchQuery = isset($_GET['search']) ? trim($_GET['search']) : '';

// Fetch products from database with optional search filter and category filter
if (!empty($searchQuery)) {
    $sql = "SELECT id, nimi, hinta, specs, kuvan_url, kategoria_id FROM puh_tuotteet WHERE nimi LIKE ? AND kategoria_id = ? ORDER BY id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['%' . $searchQuery . '%', $category]);
} else {
    $sql = "SELECT id, nimi, hinta, specs, kuvan_url, kategoria_id FROM puh_tuotteet WHERE kategoria_id = ? ORDER BY id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$category]);
}
$tuotteet = $stmt->fetchAll(PDO::FETCH_ASSOC);
$isAdmin = isset($_SESSION['rooli']) && $_SESSION['rooli'] === 'admin';

// Category names for display
$categoryNames = [
    1 => 'Puhelimet',
    2 => 'Kuoret',
    3 => 'Laturit'
];
$currentCategoryName = $categoryNames[$category] ?? 'Tuotteet';
?>
<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PhoneShop - <?= $currentCategoryName ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Header -->
    <header> 
        <div class="header-left">
            <div class="menu-icon" onclick="toggleMenu()">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
        <div class="logo">PhoneShop</div>
        <div class="header-right">
            
            <?php if ($isLoggedIn): ?>
                <span>Tervetuloa, <?php echo htmlspecialchars($nimi); ?>!</span>
                <?php if ($isAdmin): ?>
                <a class="btn btn-login" href="admin.php">Admin Panel</a>
            <?php endif; ?>
                <a class="btn btn-login" href="logout.php">Kirjaudu ulos</a>
                <div class="cart-icon" onclick="toggleCart()">
                    <img src="kuvat/ostoskori2.png" alt="Ostoskori">
                </div>
            <?php else: ?>
                <a class="btn btn-login" href="login.php">Kirjaudu</a>
                <a class="btn btn-register" href="registry.php">Rekisteröidy</a>
            <?php endif; ?>
        </div>
    </header>

    <!-- Haku palkki --> 
    <section class="search-section">
        <form method="GET" action="index.php" id="searchForm" style="display: flex; gap: 15px; align-items: center;">
            <input type="hidden" name="category" value="<?= $category ?>">
            <button type="submit" class="search-btn">Hae</button>
            <input type="text" 
                   name="search" 
                   id="searchInput"
                   class="search-input" 
                   placeholder="Tuote" 
                   value="<?= htmlspecialchars($searchQuery) ?>"
                   onkeypress="handleSearchKeyPress(event)">
            <?php if (!empty($searchQuery)): ?>
                <a href="index.php?category=<?= $category ?>" class="clear-search-btn" title="Tyhjennä haku">✕</a>
            <?php endif; ?>
        </form>
    </section>

    <!-- Tuotteet osio -->
    <section class="products-section">
        <h2 class="category-heading"><?= $currentCategoryName ?></h2>
        
        <?php if (!empty($searchQuery)): ?>
            <div class="search-results-info">
                <?php if (count($tuotteet) > 0): ?>
                    Löytyi <?= count($tuotteet) ?> tuote(tta) hakusanalla: "<strong><?= htmlspecialchars($searchQuery) ?></strong>"
                <?php else: ?>
                    Ei tuloksia hakusanalla: "<strong><?= htmlspecialchars($searchQuery) ?></strong>"
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <div class="item-grid">
            <?php if (empty($tuotteet)): ?>
                <div class="no-products">
                    <p>Tuotteita ei löytynyt.</p>
                    <?php if (!empty($searchQuery)): ?>
                        <p><a href="index.php?category=<?= $category ?>">Näytä kaikki tuotteet</a></p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach ($tuotteet as $tuote): ?>
                    <div class="product-card">
                        <div class="product-image">
                            <img src="kuvat/<?= htmlspecialchars($tuote['kuvan_url']) ?>" alt="<?= htmlspecialchars($tuote['nimi']) ?>">
                        </div>
                        <div class="product-name"><?= htmlspecialchars($tuote['nimi']) ?></div>
                        <?php if (!empty($tuote['specs'])): ?>
                            <p class="product-specs"><?= htmlspecialchars($tuote['specs']) ?></p>
                        <?php endif; ?>
                        <div class="product-hint">Hinta: <span class="hinta-numero"><?= number_format($tuote['hinta'], 2, ',', ' ') ?> €</span></div>
                        <?php if ($isLoggedIn): ?>
                            <button class="add-to-cart-btn" onclick="addToCart(<?= $tuote['id'] ?>)">Lisää ostoskoriin</button>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>

    <!-- Toast Notification -->
    <div id="toast" class="toast"></div>

    <!-- Alatunniste -->
    <footer>
        <p>Tomas ja Hassan - Savon ammattiopisto</p>
    </footer>

    <!-- Valikko sivupalkki -->
    <div id="menuSidebar" class="menu-sidebar">
        <nav class="menu-nav">
            <a href="index.php?category=1" class="menu-item <?= $category == 1 ? 'active' : '' ?>">Puhelimet</a>
            <a href="index.php?category=2" class="menu-item <?= $category == 2 ? 'active' : '' ?>">Kuoret</a>
            <a href="index.php?category=3" class="menu-item <?= $category == 3 ? 'active' : '' ?>">Laturit</a>
        </nav>
    </div>

    <?php if ($isLoggedIn): ?>
    <!-- Ostoskori sivuvalikko -->
    <div id="cartSidebar" class="cart-sidebar">
        <div class="cart-header-sidebar">
            <h2>Ostoskori</h2>
            <button class="close-cart" onclick="toggleCart()">✕</button>
        </div>
        <div class="cart-items-container" id="cartItemsContainer">
            <p class="loading-text">Ladataan...</p>
        </div>
        <div class="cart-footer-sidebar">
            <div class="cart-total">
                <span>Yhteensä:</span>
                <span id="cartTotal">0,00 €</span>
            </div>
            <a href="ostoskori.php" class="cart-button">Siirry kassalle</a>
        </div>
    </div>
    
    <?php endif; ?>

    <script>
        function handleSearchKeyPress(event) {
            if (event.key === 'Enter') {
                event.preventDefault();
                document.getElementById('searchForm').submit();
            }
        }

        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            toast.textContent = message;
            toast.className = `toast toast-${type} show`;
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        function toggleMenu() {
            const sidebar = document.getElementById('menuSidebar');
            sidebar.classList.toggle('active');
        }

        function toggleCart() {
            const sidebar = document.getElementById('cartSidebar');
            if (sidebar) {
                sidebar.classList.toggle('active');
                if (sidebar.classList.contains('active')) {
                    loadCart();
                }
            }
        }

        function addToCart(productId) {
            fetch('cart_handler.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=add&tuote_id=${productId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('✓ Tuote lisätty ostoskoriin!', 'success');
                    if (document.getElementById('cartSidebar').classList.contains('active')) {
                        loadCart();
                    }
                } else {
                    showToast('Virhe: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Virhe:', error);
                showToast('Tapahtui virhe. Yritä uudelleen.', 'error');
            });
        }

        function loadCart() {
            fetch('cart_handler.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=get'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    displayCartItems(data.items, data.total);
                } else {
                    console.error('Failed to load cart:', data);
                }
            })
            .catch(error => console.error('Virhe:', error));
        }

        function displayCartItems(items, total) {
            const container = document.getElementById('cartItemsContainer');
            const totalElement = document.getElementById('cartTotal');
            
            if (items.length === 0) {
                container.innerHTML = '<p class="empty-cart">Ostoskori on tyhjä</p>';
                totalElement.textContent = '0,00 €';
            } else {
                container.innerHTML = items.map(item => `
                    <div class="cart-item">
                        <img src="kuvat/${item.kuvan_url}" alt="${item.nimi}" class="cart-item-image">
                        <div class="cart-item-details">
                            <h3 class="cart-item-name">${item.nimi}</h3>
                            <p class="cart-item-price">${parseFloat(item.hinta).toFixed(2).replace('.', ',')} €</p>
                        </div>
                        <div class="cart-item-controls">
                            <button class="cart-btn-minus" onclick="updateQuantity(${item.tuote_id}, ${item.maara - 1})">-</button>
                            <span class="cart-item-quantity">${item.maara}</span>
                            <button class="cart-btn-plus" onclick="updateQuantity(${item.tuote_id}, ${item.maara + 1})">+</button>
                        </div>
                    </div>
                `).join('');
                
                totalElement.textContent = parseFloat(total).toFixed(2).replace('.', ',') + ' €';
            }
        }

        function updateQuantity(productId, newQuantity) {
            fetch('cart_handler.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=update&tuote_id=${productId}&maara=${newQuantity}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadCart();
                } else {
                    console.error('Update failed:', data);
                    showToast('Virhe päivityksessä', 'error');
                }
            })
            .catch(error => console.error('Virhe:', error));
        }

        // Sulje valikko kun klikataan sivuvalikon ulkopuolelle
        document.addEventListener('click', function(event) {
            const cartSidebar = document.getElementById('cartSidebar');
            const menuSidebar = document.getElementById('menuSidebar');
            const cartIcon = document.querySelector('.cart-icon');
            const menuIcon = document.querySelector('.menu-icon');
            
            if (cartSidebar && !cartSidebar.contains(event.target) && cartIcon && !cartIcon.contains(event.target)) {
                cartSidebar.classList.remove('active');
            }
            
            if (!menuSidebar.contains(event.target) && !menuIcon.contains(event.target)) {
                menuSidebar.classList.remove('active');
            }
        });
    </script>
</body>
</html>