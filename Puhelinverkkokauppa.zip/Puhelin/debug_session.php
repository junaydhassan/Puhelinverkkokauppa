<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Session Debug</title>
</head>
<body>
    <h1>Session Debug Info</h1>
    <pre>
<?php
echo "Session ID: " . session_id() . "\n\n";
echo "Session Data:\n";
print_r($_SESSION);

if (isset($_SESSION['kayttaja_id'])) {
    echo "\n\nKäyttäjä ID löytyy: " . $_SESSION['kayttaja_id'];
} else {
    echo "\n\nKäyttäjä ID PUUTTUU!";
}
?>
    </pre>
    <hr>
    <p><a href="index.php">Takaisin</a></p>
</body>
</html>